
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class Prescription {
    private int prescID;
    private String firstName;
    private String lastName;
    private String address;
    private float sphere;
    private float axis;
    private float cylinder;
    private Date examinationDate;
    private String optometrist;
    private ArrayList<String> postRemarks = new ArrayList<>(); // Store remarks added to the prescription.

    // Constructor to initialize the prescription with necessary fields.
    public Prescription(int prescID, String firstName, String lastName, String address, float sphere, float axis,
                        float cylinder, Date examinationDate, String optometrist) {
        this.prescID = prescID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.address = address;
        this.sphere = sphere;
        this.axis = axis;
        this.cylinder = cylinder;
        this.examinationDate = examinationDate;
        this.optometrist = optometrist;
    }

    // Adds the prescription to a file if all validation conditions are met.
    public boolean addPrescription() {
        // Check validity of the first name, last name, address, sphere, axis, cylinder, and optometrist name.
        if (firstName.length() >= 4 && firstName.length() <= 15 &&
                lastName.length() >= 4 && lastName.length() <= 15 &&
                address.length() >= 20 &&
                sphere >= -20.00 && sphere <= 20.00 &&
                cylinder >= -4.00 && cylinder <= 4.00 &&
                axis >= 0 && axis <= 180 &&
                optometrist.length() >= 8 && optometrist.length() <= 25) {


            // Attempt to write the prescription details to a file.
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("presc.txt", true))) {
                writer.write(prescID + "," + firstName + "," + lastName + "," + address + "," +
                        sphere + "," + axis + "," + cylinder + "," +
                        new SimpleDateFormat("dd/MM/yy").format(examinationDate) + "," +
                        optometrist + "\n");
                return true;// Prescription successfully added
            } catch (IOException e) {
                e.printStackTrace();
                return false;// File writing error
            }
        }
        return false;// Validation failed.
    }

    // Adds a remark to the prescription, if valid.
    public boolean addRemark(String remark, String remarkTypes) {
        // Validate the remark's length, capitalization, type, and ensure the remark limit is not exceeded.
        if (remark.split(" ").length >= 6 && remark.split(" ").length <= 20 &&
                Character.isUpperCase(remark.charAt(0)) &&
                (remarkTypes.equalsIgnoreCase("Client") || remarkTypes.equalsIgnoreCase("Optometrist")) &&
                postRemarks.size() < 2) {

            postRemarks.add(remark);// Add the remark to the list.

            // write to file
            try (BufferedWriter writer = new BufferedWriter(new FileWriter("remark.txt", true))) {
                writer.write(prescID + "," + remarkTypes + "," + remark + "\n");
                return true;// Remark successfully added.
            } catch (IOException e) {
                e.printStackTrace();
                return false;// File writing error.
            }
        }
        return false;// Validation failed.
    }

    // Returns the list of post-remarks added to the prescription.
    public ArrayList<String> getPostRemarks() {
        return postRemarks;
    }

    // Parses a string date in the "dd/MM/yy" format to a Date object.
    public static Date parseDate(String date) {
        try {
            return new SimpleDateFormat("dd/MM/yy").parse(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;// Return null if date parsing fails.
        }
    }
}

