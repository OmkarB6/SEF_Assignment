import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class PrescriptionTest {

    @Test// Test to validate adding a prescription with a valid first name length.
    void testAddPrescription_ValidNameLength() {
        Prescription prescription = new Prescription(1, "Omkar", "Bhise", "12 King Street, Melbourne, 3000, Australia",
                -10.0f, 80.0f, 1.0f, Prescription.parseDate("21/10/24"), "Dr. Sahil Kalamkar");
        assertTrue(prescription.addPrescription(), "Valid first name length");
    }

    @Test// Test to check adding a prescription fails when the first name length is invalid.
    void testAddPrescription_InvalidNameLength() {
        Prescription prescription = new Prescription(2, "Sam", "Lee", "101 Queen Street, Melbourne, 3000, Australia",
                -10.0f, 90.0f, 2.0f, Prescription.parseDate("21/10/24"), "Dr. Sahil Kalamkar");
        assertFalse(prescription.addPrescription(), "Invalid first name length");
    }

    @Test// Test to check adding a prescription fails when the address length is too short.
    void testAddPrescription_InvalidAddressLength() {
        Prescription prescription = new Prescription(3, "Ankita", "Gaware", "Melbourne",
                -10.0f, 90.0f, 2.0f, Prescription.parseDate("21/10/24"), "Dr. Sahil Kalamkar");
        assertFalse(prescription.addPrescription(), "Invalid address length");
    }

    @Test// Test to check adding a prescription fails when the sphere value is outside the valid range.
    void testAddPrescription_InvalidSphere() {
        Prescription prescription = new Prescription(4, "Omkar", "Bhise", "12 King Street, Melbourne, 3000, Australia",
                25.0f, 90.0f, 2.0f, Prescription.parseDate("21/10/24"), "Dr. Sahil Kalamkar");
        assertFalse(prescription.addPrescription(), "Invalid sphere value");
    }

    @Test// Test to validate adding a remark with a valid length and remark type.
    void testAddRemark_ValidLength() {
        Prescription prescription = new Prescription(1, "Omkar", "Bhise", "12 King Street, Melbourne, 3000, Australia",
                -10.0f, 90.0f, 2.0f, Prescription.parseDate("21/10/24"), "Dr. Sahil Kalamkar");
        assertTrue(prescription.addRemark("The client was happy after the eye examination.", "Client"),
                "Valid remark");
    }

    @Test// Test to ensure adding a remark fails when the remark is too short.
    void testAddRemark_InvalidRemarkLength() {
        Prescription prescription = new Prescription(2, "Omkar", "Bhise", "12 King Street, Melbourne, 3000, Australia",
                -10.0f, 90.0f, 2.0f, Prescription.parseDate("21/10/24"), "Dr. Sahil Kalamkar");
        assertFalse(prescription.addRemark("Happy test", "Client"), "Remark too short");
    }

    @Test// Test to ensure adding a remark fails when an invalid remark type is provided.
    void testAddRemark_InvalidRemarkType() {
        Prescription prescription = new Prescription(3, "Omkar", "Bhise", "12 King Street, Melbourne, 3000, Australia",
                -10.0f, 90.0f, 2.0f, Prescription.parseDate("21/10/24"), "Dr. Sahil Kalamkar");
        assertFalse(prescription.addRemark("The client was happy after the eye examination.", "Staff"),
                "Invalid remark type");
    }

    @Test// Test to ensure adding a remark fails when the first character is not capitalized.
    void testAddRemark_InvalidCapitalization() {
        Prescription prescription = new Prescription(4, "omkar", "Bhise", "12 King Street, Melbourne, 3000, Australia",
                -10.0f, 90.0f, 2.0f, Prescription.parseDate("21/10/24"), "Dr. Sahil Kalamkar");
        assertFalse(prescription.addRemark("the client was happy after the eye examination.", "Client"),
                "Invalid remark type");
    }

    @Test// Test to ensure adding more than two remarks fails.
    void testAddRemark_ExceedingRemarkLimit() {
        Prescription prescription = new Prescription(5, "Omkar", "Bhise", "12 King Street, Melbourne, 3000, Australia",
                -10.0f, 90.0f, 2.0f, Prescription.parseDate("21/10/24"), "Dr. Sahil Kalamkar");
        prescription.addRemark("The client was happy after the eye examination.", "Client");
        prescription.addRemark("Optometrist recommended daily use of eye drops.", "Optometrist");
        assertFalse(prescription.addRemark("patient felt tired during the test.", "Client"),
                "Exceeding remark limit");
    }
}
